import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { apiClient } from '../services/apiClient'
import { Salon, Service } from '../types'
import LoadingSpinner from '../components/common/LoadingSpinner'
import { MapPin, Phone, Clock, Star, Check } from 'lucide-react'

export default function SalonDetailsPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  
  const [salon, setSalon] = useState<Salon | null>(null)
  const [services, setServices] = useState<Service[]>([])
  const [selectedServices, setSelectedServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (id) {
      fetchSalonDetails()
      fetchServices()
    }
  }, [id])

  const fetchSalonDetails = async () => {
    try {
      console.log('🔄 Fetching salon details for:', id)
      const data = await apiClient.getSalonById(id!)
      console.log('✅ Got salon:', data)
      setSalon(data)
    } catch (error) {
      console.error('❌ Failed to fetch salon:', error)
    }
  }

  const fetchServices = async () => {
    try {
      console.log('🔄 Fetching services for salon:', id)
      const data = await apiClient.getServicesBySalonId(id!)
      console.log('✅ Got services with images:', data)
      console.log('📸 First service image:', data[0]?.image)
      setServices(data)
    } catch (error) {
      console.error('❌ Failed to fetch services:', error)
    } finally {
      setLoading(false)
    }
  }

  const toggleServiceSelection = (service: Service) => {
  setSelectedServices(prev => {
    // Get the actual ID to compare
    const serviceId = service.id || service._id
    
    // Check if already selected
    const isSelected = prev.find(s => {
      const existingId = s.id || s._id
      return existingId === serviceId
    })
    
    if (isSelected) {
      // Remove it
      return prev.filter(s => {
        const existingId = s.id || s._id
        return existingId !== serviceId
      })
    } else {
      // Add it
      return [...prev, service]
    }
  })
}

const isServiceSelected = (service: Service) => {
  const serviceId = service.id || service._id
  return selectedServices.some(s => {
    const existingId = s.id || s._id
    return existingId === serviceId
  })
}

  const totalPrice = selectedServices.reduce((sum, service) => sum + service.price, 0)
  const totalDuration = selectedServices.reduce((sum, service) => sum + service.duration, 0)

  const handleBookNow = () => {
    if (selectedServices.length === 0) {
      alert('Please select at least one service')
      return
    }
    
    navigate('/booking', {
      state: {
        salon,
        services: selectedServices,
        totalPrice,
        totalDuration
      }
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner />
      </div>
    )
  }

  if (!salon) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-gray-600">Salon not found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-32">
      {/* Salon Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-start gap-6">
            {salon.image && (
              <img
                src={salon.image}
                alt={salon.name}
                className="w-32 h-32 rounded-lg object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement
                  target.style.display = 'none'
                }}
              />
            )}
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{salon.name}</h1>
              
              <div className="flex items-center gap-4 text-gray-600 mb-4 flex-wrap">
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{salon.address}, {salon.city}</span>
                </div>
                {salon.phone && (
                  <div className="flex items-center gap-1">
                    <Phone className="w-4 h-4" />
                    <span>{salon.phone}</span>
                  </div>
                )}
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold">{salon.rating}</span>
                </div>
              </div>

              {salon.description && (
                <p className="text-gray-600">{salon.description}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Services</h2>

        {services.length === 0 ? (
          <div className="bg-white rounded-lg p-8 text-center">
            <p className="text-gray-600">No services available at this salon</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => {
              const selected = isServiceSelected(service)
              return (
                <div
                  key={service.id || service._id}
                  onClick={() => toggleServiceSelection(service)}
                  className={`bg-white rounded-lg overflow-hidden cursor-pointer transition-all ${
                    selected
                      ? 'ring-2 ring-blue-500 shadow-lg'
                      : 'hover:shadow-md border border-gray-200'
                  }`}
                >
                  {/* Service Image */}
                  <div className="relative h-48 bg-gradient-to-br from-slate-100 to-slate-50">
                    {service.image ? (
                      <img
                        src={service.image}
                        alt={service.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement
                          target.src = 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&h=300&fit=crop'
                        }}
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <span className="text-6xl">✂️</span>
                      </div>
                    )}
                    
                    {/* Selection Indicator */}
                    {selected && (
                      <div className="absolute top-3 right-3 bg-blue-500 text-white rounded-full p-2 shadow-lg">
                        <Check className="w-5 h-5" />
                      </div>
                    )}
                  </div>

                  {/* Service Details */}
                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {service.name}
                    </h3>

                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                      {service.description}
                    </p>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-gray-500">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm">{service.duration} min</span>
                      </div>
                      <div className="text-xl font-bold text-blue-600">
                        ₹{service.price}
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Fixed Bottom Booking Bar */}
      {selectedServices.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="text-sm text-gray-600 mb-1">
                  {selectedServices.length} service{selectedServices.length > 1 ? 's' : ''} selected
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-2xl font-bold text-gray-900">
                    ₹{totalPrice}
                  </div>
                  <div className="flex items-center gap-1 text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>{totalDuration} min</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleBookNow}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition shadow-lg"
              >
                Book Now →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}