import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { apiClient } from '../services/apiClient'
import { Salon, Service } from '../types'
import { getUsername } from '../services/keycloakService'

export default function BookingPage() {
  const location = useLocation()
  const navigate = useNavigate()
  
  const { salon, services, totalPrice } = location.state as {
    salon: Salon
    services: Service[]
    totalPrice: number
  }

  const [selectedDate, setSelectedDate] = useState('')
  const [selectedTime, setSelectedTime] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const username = getUsername()

  // Generate available time slots
  const timeSlots = [
    '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
    '12:00', '12:30', '13:00', '13:30', '14:00', '14:30',
    '15:00', '15:30', '16:00', '16:30', '17:00', '17:30',
    '18:00', '18:30', '19:00'
  ]

  const getMinDate = () => {
    const today = new Date()
    return today.toISOString().split('T')[0]
  }

  const getMaxDate = () => {
    const maxDate = new Date()
    maxDate.setDate(maxDate.getDate() + 30)
    return maxDate.toISOString().split('T')[0]
  }

  const handleBooking = async () => {
    if (!selectedDate || !selectedTime) {
      setError('Please select both date and time')
      return
    }

    try {
      setLoading(true)
      setError(null)

      // Get user info
      const userInfo = JSON.parse(localStorage.getItem('user') || '{}')
      const keycloakId = userInfo.sub
      const email = userInfo.email || ''
      const name = userInfo.name || username || ''

      console.log('👤 User info:', { keycloakId, email, name })

      if (!keycloakId) {
        throw new Error('User not authenticated. Please login again.')
      }

      // Calculate total duration
      const totalDuration = services.reduce((sum, s) => sum + s.duration, 0)

      // Create start and end times
      const startDateTime = new Date(`${selectedDate}T${selectedTime}:00`)
      const endDateTime = new Date(startDateTime.getTime() + totalDuration * 60000)

      // STEP 1: Create booking first (PENDING status)
      const bookingData = {
        salonId: salon.id,
        customerId: keycloakId,
        customerName: name,
        customerEmail: email,
        serviceIds: services.map(s => s.id),
        startTime: startDateTime.toISOString(),
        endTime: endDateTime.toISOString(),
        totalPrice: totalPrice,
        paymentMethod: 'CARD',
        status: 'PENDING'
      }

      console.log('📅 Creating booking:', bookingData)

      // Create the booking
      const bookingResponse = await apiClient.createBooking(bookingData)
      
      console.log('✅ Booking created:', bookingResponse)
      
      // Booking confirmation email is sent by backend here

      // STEP 2: Create payment link with the booking
      console.log('💳 Creating payment link for booking:', bookingResponse.id || bookingResponse._id)

      const paymentResponse = await apiClient.createPaymentLink(bookingResponse)
      
      console.log('✅ Payment link created:', paymentResponse)

      // STEP 3: Redirect to Stripe
      if (paymentResponse.payment_link_url) {
        console.log('🔗 Redirecting to Stripe:', paymentResponse.payment_link_url)
        
        // Store booking ID for later
        sessionStorage.setItem('pendingBookingId', bookingResponse.id || bookingResponse._id)
        
        // Redirect to Stripe payment
        window.location.href = paymentResponse.payment_link_url
      } else {
        console.error('❌ No payment_link_url:', paymentResponse)
        throw new Error('Payment link not received from server')
      }

    } catch (err: any) {
      console.error('❌ Full error:', err)
      console.error('❌ Error response:', err.response)
      console.error('❌ Error data:', err.response?.data)
      console.error('❌ Error status:', err.response?.status)
      
      setError(
        err.response?.data?.message || 
        err.response?.data ||
        err.message || 
        'Failed to process booking. Please try again.'
      )
      setLoading(false)
    }
  }

  const getTotalDuration = () => {
    return services.reduce((sum, s) => sum + s.duration, 0)
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-slate-900 mb-8">Complete Your Booking</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Booking Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Salon Info */}
          <div className="bg-white rounded-lg shadow-md p-6 border border-slate-200">
            <h2 className="text-xl font-bold text-slate-900 mb-4">Salon Details</h2>
            <div className="space-y-2">
              <p className="text-lg font-semibold text-slate-900">{salon.name}</p>
              <p className="text-slate-600 flex items-center gap-2">
                <span>📍</span>
                {salon.address}, {salon.city}
              </p>
            </div>
          </div>

          {/* Selected Services */}
          <div className="bg-white rounded-lg shadow-md p-6 border border-slate-200">
            <h2 className="text-xl font-bold text-slate-900 mb-4">Selected Services</h2>
            <div className="space-y-3">
              {services.map((service) => (
                <div key={service.id} className="flex justify-between items-center py-2 border-b border-slate-100 last:border-0">
                  <div>
                    <p className="font-semibold text-slate-900">{service.name}</p>
                    <p className="text-sm text-slate-600">{service.duration} min</p>
                  </div>
                  <p className="font-bold text-slate-900">₹{service.price}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Date & Time Selection */}
          <div className="bg-white rounded-lg shadow-md p-6 border border-slate-200">
            <h2 className="text-xl font-bold text-slate-900 mb-4">Select Date & Time</h2>
            
            {/* Date Picker */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Select Date
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={getMinDate()}
                max={getMaxDate()}
                className="w-full px-4 py-3 border-2 border-slate-300 rounded-lg focus:border-blue-500 focus:outline-none text-lg"
              />
            </div>

            {/* Time Picker */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Select Time Slot
              </label>
              <div className="grid grid-cols-4 gap-3">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`px-4 py-3 rounded-lg font-semibold transition ${
                      selectedTime === time
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border-2 border-red-200 text-red-700 px-4 py-3 rounded-lg">
              <p className="font-semibold">⚠️ Error</p>
              <p className="text-sm">{typeof error === 'string' ? error : JSON.stringify(error)}</p>
            </div>
          )}
        </div>

        {/* Booking Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-blue-200 sticky top-4">
            <h2 className="text-xl font-bold text-slate-900 mb-4">Booking Summary</h2>
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-slate-600">
                <span>Services ({services.length})</span>
                <span className="font-semibold">₹{totalPrice}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Duration</span>
                <span className="font-semibold">{getTotalDuration()} min</span>
              </div>
              {selectedDate && (
                <div className="flex justify-between text-slate-600">
                  <span>Date</span>
                  <span className="font-semibold">{new Date(selectedDate).toLocaleDateString()}</span>
                </div>
              )}
              {selectedTime && (
                <div className="flex justify-between text-slate-600">
                  <span>Time</span>
                  <span className="font-semibold">{selectedTime}</span>
                </div>
              )}
            </div>

            <div className="border-t-2 border-slate-200 pt-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-slate-900">Total</span>
                <span className="text-2xl font-bold text-blue-600">₹{totalPrice}</span>
              </div>
            </div>

            <button
              onClick={handleBooking}
              disabled={loading || !selectedDate || !selectedTime}
              className={`w-full py-4 rounded-lg font-bold text-lg transition ${
                loading || !selectedDate || !selectedTime
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg'
              }`}
            >
              {loading ? '🔄 Processing...' : '📅 Book Now'}
            </button>

            <p className="text-xs text-slate-500 text-center mt-4">
              Click "Book Now" to receive confirmation email, then proceed to payment
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}